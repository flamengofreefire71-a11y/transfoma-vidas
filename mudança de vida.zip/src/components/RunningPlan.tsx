import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Trophy, ChevronDown, ChevronUp, CheckCircle2, Circle, Star } from 'lucide-react';
import { runningPlan, PRICE_PREMIUM, WHATSAPP } from '../data/content';

interface Props {
  isDark: boolean;
  accessLevel: 'none' | 'vip' | 'premium';
  onUnlock: (area: 'vip' | 'premium') => void;
}

const typeStyle: Record<string, string> = {
  walk:     'bg-blue-500/10 text-blue-500',
  interval: 'bg-orange-500/10 text-orange-500',
  run:      'bg-emerald-500/10 text-emerald-600',
  goal:     'bg-amber-500/10 text-amber-600',
  rest:     'bg-slate-500/10 text-slate-400',
};

export default function RunningPlan({ isDark, accessLevel, onUnlock }: Props) {
  const [expanded, setExpanded] = useState<number | null>(0);
  const [done, setDone] = useState<Set<string>>(new Set());

  const toggle = (wi: number, di: number) => {
    const key = `${wi}-${di}`;
    setDone(prev => { const n = new Set(prev); n.has(key) ? n.delete(key) : n.add(key); return n; });
  };

  if (accessLevel !== 'premium') {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
        className={`rounded-3xl border-2 border-dashed p-10 text-center ${isDark ? 'border-slate-700 bg-slate-900' : 'border-slate-200 bg-slate-50'}`}>
        <div className={`w-20 h-20 mx-auto mb-5 rounded-2xl flex items-center justify-center ${isDark ? 'bg-amber-500/10' : 'bg-amber-50'}`}>
          <Lock className="w-10 h-10 text-amber-500" />
        </div>
        <h3 className={`text-2xl font-bold mb-3 ${isDark ? 'text-white' : 'text-slate-900'}`}>
          Conteúdo Exclusivo Premium
        </h3>
        <p className={`max-w-md mx-auto mb-6 text-sm leading-relaxed ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          O plano completo de 8 semanas — do zero aos 5km — está disponível apenas para membros Premium.
        </p>
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {['8 Semanas de Treino', 'Cronograma Diário', 'Prevenção de Lesões', 'Técnica de Corrida', 'Progresso Visual'].map(t => (
            <span key={t} className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium ${isDark ? 'bg-slate-800 text-slate-300' : 'bg-white text-slate-500 border border-slate-200'}`}>
              <Lock className="w-3 h-3" /> {t}
            </span>
          ))}
        </div>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
            onClick={() => onUnlock('premium')}
            className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-gradient-to-r from-blue-800 to-indigo-950 text-white font-bold rounded-xl shadow-lg cursor-pointer">
            <Star className="w-5 h-5" /> Desbloquear por {PRICE_PREMIUM}
          </motion.button>
          <a href={`https://wa.me/${WHATSAPP}?text=Olá!%20Quero%20o%20acesso%20Premium%20do%20TransformaVida`}
            target="_blank" rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-emerald-500 text-white font-bold rounded-xl shadow-lg cursor-pointer hover:bg-emerald-600 transition-colors">
            📱 Falar no WhatsApp
          </a>
        </div>
      </motion.div>
    );
  }

  const total = runningPlan.reduce((a, w) => a + w.sessions.length, 0);
  const progress = Math.round((done.size / total) * 100);

  return (
    <div className="space-y-5">
      <div className="text-center">
        <h2 className={`text-2xl font-bold mb-1 ${isDark ? 'text-white' : 'text-slate-900'}`}>Plano de Corrida — Do Zero aos 5KM</h2>
        <p className={`text-sm ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>8 semanas • Marque cada treino concluído</p>
      </div>

      {/* Progress bar */}
      <div className={`rounded-2xl p-5 border ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100 shadow-sm'}`}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-500" />
            <span className={`font-bold text-sm ${isDark ? 'text-white' : 'text-slate-900'}`}>Seu Progresso</span>
          </div>
          <span className={`text-xl font-extrabold ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>{progress}%</span>
        </div>
        <div className={`w-full h-3 rounded-full ${isDark ? 'bg-slate-800' : 'bg-slate-100'}`}>
          <motion.div className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full"
            animate={{ width: `${progress}%` }} transition={{ duration: 0.8 }} />
        </div>
        <p className={`text-xs mt-2 ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>{done.size} de {total} treinos completados</p>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-2">
        {[['walk','🚶 Caminhada'],['interval','⚡ Intervalado'],['run','🏃 Corrida'],['goal','🏆 Objetivo'],['rest','💤 Descanso']].map(([k,l]) => (
          <span key={k} className={`px-2.5 py-1 rounded-lg text-xs font-medium ${typeStyle[k] ?? typeStyle.rest}`}>{l}</span>
        ))}
      </div>

      {/* Weeks */}
      {runningPlan.map((week, wi) => {
        const wDone = week.sessions.filter((_, di) => done.has(`${wi}-${di}`)).length;
        const isOpen = expanded === wi;
        const allDone = wDone === week.sessions.length;
        return (
          <motion.div key={week.week} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: wi * 0.04 }}
            className={`rounded-2xl border overflow-hidden ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100 shadow-sm'}`}>
            <button onClick={() => setExpanded(isOpen ? null : wi)}
              className="w-full flex items-center gap-4 px-5 py-4 text-left cursor-pointer">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-extrabold text-sm shrink-0 ${allDone ? 'bg-emerald-500 text-white' : isDark ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-600'}`}>
                {allDone ? <CheckCircle2 className="w-6 h-6" /> : `S${week.week}`}
              </div>
              <div className="flex-1 min-w-0">
                <p className={`font-bold truncate ${isDark ? 'text-white' : 'text-slate-900'}`}>Semana {week.week}: {week.title}</p>
                <p className={`text-xs truncate ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>{week.desc}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className={`text-xs font-semibold px-2 py-1 rounded-lg ${isDark ? 'bg-slate-800 text-slate-400' : 'bg-slate-100 text-slate-500'}`}>{wDone}/{week.sessions.length}</span>
                {isOpen ? <ChevronUp className="w-5 h-5 text-slate-400" /> : <ChevronDown className="w-5 h-5 text-slate-400" />}
              </div>
            </button>
            <AnimatePresence>
              {isOpen && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }} className="overflow-hidden">
                  <div className={`border-t ${isDark ? 'border-slate-800' : 'border-slate-100'}`}>
                    {week.sessions.map((s, di) => {
                      const key = `${wi}-${di}`;
                      const isDone = done.has(key);
                      const clickable = s.type !== 'rest';
                      return (
                        <div key={di} onClick={() => clickable && toggle(wi, di)}
                          className={`flex items-center gap-3 px-5 py-3 border-b last:border-0 ${isDark ? 'border-slate-800' : 'border-slate-50'} ${clickable ? 'cursor-pointer' : ''} transition-colors ${clickable && !isDark ? 'hover:bg-slate-50' : ''} ${clickable && isDark ? 'hover:bg-slate-800/40' : ''}`}>
                          <div className="shrink-0">
                            {isDone ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <Circle className={`w-5 h-5 ${clickable ? 'text-slate-300' : 'text-slate-200'}`} />}
                          </div>
                          <span className={`text-xs font-bold px-2 py-1 rounded-md shrink-0 ${typeStyle[s.type] ?? typeStyle.rest}`}>{s.day}</span>
                          <span className={`text-sm flex-1 ${isDone ? 'line-through opacity-50' : ''} ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>{s.activity}</span>
                          {s.type === 'goal' && <Trophy className="w-4 h-4 text-amber-500 shrink-0" />}
                        </div>
                      );
                    })}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        );
      })}
    </div>
  );
}
