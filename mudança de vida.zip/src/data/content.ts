export const WHATSAPP = '5521974633380';
export const PRICE_VIP = 'R$ 30,90';
export const PRICE_PREMIUM = 'R$ 40,90';
export const CODE_VIP = '1975';
export const CODE_PREMIUM = '2809';

export const bibleVerses = [
  { verse: 'Tudo posso naquele que me fortalece.', ref: 'Filipenses 4:13' },
  { verse: 'Não sabeis que o vosso corpo é santuário do Espírito Santo?', ref: '1 Coríntios 6:19' },
  { verse: 'Porque Deus não nos deu espírito de covardia, mas de poder, de amor e de moderação.', ref: '2 Timóteo 1:7' },
  { verse: 'O homem preguiçoso não alcançará o que deseja, mas o diligente será prosperado.', ref: 'Provérbios 13:4' },
  { verse: 'Seja a vossa moderação notória a todos os homens.', ref: 'Filipenses 4:5' },
  { verse: 'Tudo me é lícito, mas nem tudo me convém.', ref: '1 Coríntios 6:12' },
  { verse: 'O corpo não é para a imoralidade, mas para o Senhor, e o Senhor para o corpo.', ref: '1 Coríntios 6:13' },
  { verse: 'Honra ao Senhor com os teus bens e com as primícias de toda a tua renda.', ref: 'Provérbios 3:9' },
];

export const notifications = [
  '🔥 Você está mais perto do seu objetivo do que imagina!',
  '💪 Cada gota de suor é um investimento no seu futuro!',
  '🌟 O corpo alcança o que a mente acredita!',
  '⚡ Hoje é o dia perfeito para superar seus limites!',
  '🎯 Sua disciplina de hoje é o seu corpo de amanhã!',
  '💚 Não pare quando estiver cansada — pare quando terminar!',
  '🏃‍♀️ Seu futuro eu vai agradecer pela decisão de hoje!',
  '🌈 Consistência é mais importante que intensidade!',
  '💎 Você é mais forte do que imagina!',
  '⭐ A jornada de mil milhas começa com um único passo!',
];

export const weightLossTips = [
  {
    emoji: '💧',
    title: 'Beba água antes de comer',
    text: 'Tomar um copo de água 30 minutos antes das refeições reduz a fome em até 30%. Beba pelo menos 2,5 litros por dia para acelerar o metabolismo.',
    color: 'blue',
  },
  {
    emoji: '🥚',
    title: 'Proteína em cada refeição',
    text: 'A proteína é o nutriente mais saciante. Ovos, frango, peixe e leguminosas preservam a massa muscular e queimam mais calorias na digestão.',
    color: 'orange',
  },
  {
    emoji: '😴',
    title: 'Durma 7 a 9 horas por noite',
    text: 'Dormir pouco eleva o cortisol e aumenta a fome em até 25%. Quem dorme bem emagrece até 2x mais rápido do que quem dorme mal.',
    color: 'purple',
  },
  {
    emoji: '🚫',
    title: 'Corte o açúcar refinado',
    text: 'O açúcar refinado é o maior vilão. Ele causa picos de insulina que promovem acúmulo de gordura. Substitua por frutas e adoçantes naturais.',
    color: 'red',
  },
  {
    emoji: '🕐',
    title: 'Coma a cada 3 horas',
    text: 'Fracionando as refeições você evita a fome excessiva, mantém o metabolismo ativo e controla melhor as porções ao longo do dia.',
    color: 'teal',
  },
  {
    emoji: '🧠',
    title: 'Reduza o estresse',
    text: 'O cortisol, hormônio do estresse, promove acúmulo de gordura abdominal. Pratique respiração profunda, meditação ou caminhadas na natureza.',
    color: 'pink',
  },
  {
    emoji: '🥗',
    title: 'Metade do prato de legumes',
    text: 'Preencher metade do prato com vegetais coloridos garante saciedade com poucas calorias, além de fornecer vitaminas e minerais essenciais.',
    color: 'green',
  },
  {
    emoji: '🚶‍♀️',
    title: 'Mova-se todos os dias',
    text: 'Não precisa de academia. Caminhar 30 min por dia já cria o hábito de se mover. A consistência é mais importante do que a intensidade.',
    color: 'emerald',
  },
];

export const mealPlan = [
  {
    meal: 'Café da Manhã', time: '07h00',
    items: ['2 ovos mexidos com azeite', '1 fatia de pão integral', '½ abacate amassado', 'Chá verde sem açúcar'],
    kcal: 350,
  },
  {
    meal: 'Lanche da Manhã', time: '10h00',
    items: ['1 maçã média', '10 castanhas-do-pará'],
    kcal: 180,
  },
  {
    meal: 'Almoço', time: '13h00',
    items: ['150g de peito de frango grelhado', '4 col. de arroz integral', 'Salada verde à vontade', '1 col. de azeite extra virgem'],
    kcal: 520,
  },
  {
    meal: 'Lanche da Tarde', time: '16h00',
    items: ['1 iogurte natural desnatado', '1 col. de chia', 'Morangos picados a gosto'],
    kcal: 200,
  },
  {
    meal: 'Jantar', time: '19h30',
    items: ['1 filé de peixe assado com ervas', 'Brócolis e cenoura no vapor', 'Sopa leve de legumes'],
    kcal: 380,
  },
  {
    meal: 'Ceia (opcional)', time: '21h30',
    items: ['Chá de camomila ou hortelã', '2 quadradinhos de chocolate 70%'],
    kcal: 90,
  },
];

export const runningPlan = [
  {
    week: 1, title: 'Acordando o Corpo',
    desc: 'O objetivo é criar o hábito. Sem pressa, sem pressão.',
    sessions: [
      { day: 'Seg', activity: 'Caminhada leve por 20 minutos', type: 'walk' },
      { day: 'Ter', activity: 'Descanso ativo — alongamento 15 min', type: 'rest' },
      { day: 'Qua', activity: 'Caminhada por 25 minutos', type: 'walk' },
      { day: 'Qui', activity: 'Descanso completo', type: 'rest' },
      { day: 'Sex', activity: 'Caminhada por 20 minutos', type: 'walk' },
      { day: 'Sáb', activity: 'Caminhada por 30 minutos', type: 'walk' },
      { day: 'Dom', activity: 'Descanso completo', type: 'rest' },
    ],
  },
  {
    week: 2, title: 'Primeiros Trotinhos',
    desc: 'Introduzindo pequenos intervalos de corrida leve.',
    sessions: [
      { day: 'Seg', activity: '5 min caminhada + 5× (1 min corrida / 1 min caminhada)', type: 'interval' },
      { day: 'Ter', activity: 'Descanso ou yoga leve', type: 'rest' },
      { day: 'Qua', activity: '5 min caminhada + 6× (1 min corrida / 1 min caminhada)', type: 'interval' },
      { day: 'Qui', activity: 'Descanso completo', type: 'rest' },
      { day: 'Sex', activity: 'Caminhada por 25 minutos', type: 'walk' },
      { day: 'Sáb', activity: '5 min caminhada + 8× (1 min corrida / 1 min caminhada)', type: 'interval' },
      { day: 'Dom', activity: 'Descanso completo', type: 'rest' },
    ],
  },
  {
    week: 3, title: 'Aumentando a Resistência',
    desc: 'Mais corrida, menos pausas.',
    sessions: [
      { day: 'Seg', activity: '5× (2 min corrida / 1 min caminhada)', type: 'interval' },
      { day: 'Ter', activity: 'Caminhada leve 20 min', type: 'walk' },
      { day: 'Qua', activity: '4× (3 min corrida / 1,5 min caminhada)', type: 'interval' },
      { day: 'Qui', activity: 'Descanso completo', type: 'rest' },
      { day: 'Sex', activity: '5× (2 min corrida / 1 min caminhada)', type: 'interval' },
      { day: 'Sáb', activity: 'Caminhada 30 min em ritmo firme', type: 'walk' },
      { day: 'Dom', activity: 'Descanso completo', type: 'rest' },
    ],
  },
  {
    week: 4, title: 'Correndo de Verdade',
    desc: 'Intervalos maiores e foco na respiração.',
    sessions: [
      { day: 'Seg', activity: '4× (4 min corrida / 2 min caminhada)', type: 'interval' },
      { day: 'Ter', activity: 'Caminhada leve 25 min', type: 'walk' },
      { day: 'Qua', activity: '3× (5 min corrida / 2 min caminhada)', type: 'interval' },
      { day: 'Qui', activity: 'Descanso completo', type: 'rest' },
      { day: 'Sex', activity: '4× (4 min corrida / 1 min caminhada)', type: 'interval' },
      { day: 'Sáb', activity: 'Caminhada 35 min', type: 'walk' },
      { day: 'Dom', activity: 'Descanso completo', type: 'rest' },
    ],
  },
  {
    week: 5, title: 'Quase Parando de Parar',
    desc: 'Menos pausas, mais fôlego.',
    sessions: [
      { day: 'Seg', activity: '3× (7 min corrida / 2 min caminhada)', type: 'interval' },
      { day: 'Ter', activity: 'Caminhada leve 20 min', type: 'walk' },
      { day: 'Qua', activity: '2× (10 min corrida / 2 min caminhada)', type: 'interval' },
      { day: 'Qui', activity: 'Descanso completo', type: 'rest' },
      { day: 'Sex', activity: '3× (8 min corrida / 1 min caminhada)', type: 'interval' },
      { day: 'Sáb', activity: 'Caminhada firme 30 min', type: 'walk' },
      { day: 'Dom', activity: 'Descanso completo', type: 'rest' },
    ],
  },
  {
    week: 6, title: 'Corrida Contínua',
    desc: 'Agora você já consegue correr sem parar!',
    sessions: [
      { day: 'Seg', activity: '15 minutos de corrida contínua', type: 'run' },
      { day: 'Ter', activity: 'Caminhada leve 25 min', type: 'walk' },
      { day: 'Qua', activity: '18 minutos de corrida contínua', type: 'run' },
      { day: 'Qui', activity: 'Descanso completo', type: 'rest' },
      { day: 'Sex', activity: '15 minutos de corrida contínua', type: 'run' },
      { day: 'Sáb', activity: 'Caminhada 35 min', type: 'walk' },
      { day: 'Dom', activity: 'Descanso completo', type: 'rest' },
    ],
  },
  {
    week: 7, title: 'Expandindo o Fôlego',
    desc: 'Distâncias maiores sem sentir.',
    sessions: [
      { day: 'Seg', activity: '20 minutos de corrida contínua', type: 'run' },
      { day: 'Ter', activity: 'Caminhada leve 20 min', type: 'walk' },
      { day: 'Qua', activity: '22 minutos de corrida contínua', type: 'run' },
      { day: 'Qui', activity: 'Descanso completo', type: 'rest' },
      { day: 'Sex', activity: '20 minutos de corrida contínua', type: 'run' },
      { day: 'Sáb', activity: 'Caminhada 30 min', type: 'walk' },
      { day: 'Dom', activity: 'Descanso completo', type: 'rest' },
    ],
  },
  {
    week: 8, title: '🏆 Chegou a Hora dos 5KM!',
    desc: 'Você está pronta para completar os primeiros 5km da sua vida!',
    sessions: [
      { day: 'Seg', activity: '25 minutos de corrida contínua', type: 'run' },
      { day: 'Ter', activity: 'Caminhada leve 20 min + alongamento', type: 'walk' },
      { day: 'Qua', activity: '28 minutos de corrida contínua', type: 'run' },
      { day: 'Qui', activity: 'Descanso completo — guarde energia!', type: 'rest' },
      { day: 'Sex', activity: 'Corrida leve 15 min — aquecimento', type: 'run' },
      { day: 'Sáb', activity: '🎉 CORRA SEUS 5KM COMPLETOS!', type: 'goal' },
      { day: 'Dom', activity: 'Descanso total — você merece!', type: 'rest' },
    ],
  },
];

export const testimonials = [
  { name: 'Ana Carolina S.', age: 32, lost: '12kg', time: '3 meses', text: 'Nunca pensei que conseguiria. O programa me deu disciplina e os versículos me mantiveram firme!' },
  { name: 'Marcos Paulo R.', age: 28, lost: '18kg', time: '4 meses', text: 'O plano de corrida mudou minha vida. Hoje corro 10km toda semana e me sinto outra pessoa.' },
  { name: 'Juliana M.', age: 41, lost: '9kg', time: '2 meses', text: 'As notificações de incentivo chegavam sempre na hora certa. Me ajudaram demais a não desistir!' },
];

export const secretTruths = [
  {
    title: 'Por que 95% das dietas falham',
    text: 'A indústria do fitness quer que você compre suplementos eternamente. A verdade é que déficit calórico + hábitos simples funcionam melhor do que qualquer produto.',
    emoji: '💡',
  },
  {
    title: 'O hormônio que controla sua fome',
    text: 'A insulina e a leptina são os verdadeiros controladores do seu peso. Regular esses hormônios naturalmente é mais eficaz do que qualquer dieta da moda.',
    emoji: '🧬',
  },
  {
    title: 'O erro que destrói o metabolismo',
    text: 'Passar horas na esteira sem mudar a alimentação pode aumentar o cortisol e te fazer engordar. O segredo está no equilíbrio entre exercício e descanso.',
    emoji: '⚠️',
  },
  {
    title: 'A verdade sobre o cardio',
    text: 'Horas de cardio moderado podem ser menos eficientes que 20 minutos de treino intervalado. A ciência já provou isso há anos — mas ninguém quer que você saiba.',
    emoji: '🔬',
  },
];
